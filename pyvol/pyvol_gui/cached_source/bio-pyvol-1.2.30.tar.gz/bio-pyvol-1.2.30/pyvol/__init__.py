
__version__ = "1.2.30"
__guiversion__ = "1.1.2"
