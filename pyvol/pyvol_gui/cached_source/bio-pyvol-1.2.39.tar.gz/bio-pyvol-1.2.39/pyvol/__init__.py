
__version__ = "1.2.39"
__guiversion__ = "1.1.7"
