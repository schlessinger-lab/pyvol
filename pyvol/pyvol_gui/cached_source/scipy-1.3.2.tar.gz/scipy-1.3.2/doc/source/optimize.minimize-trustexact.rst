.. _optimize.minimize-trustexact:

minimize(method='trust-exact')
-------------------------------------------

.. scipy-optimize:function:: scipy.optimize.minimize
   :impl: scipy.optimize._trustregion_exact._minimize_trustregion_exact
   :method: trust-exact
