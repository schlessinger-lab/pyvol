.. _optimize.root-hybr:

root(method='hybr')
----------------------------------

.. scipy-optimize:function:: scipy.optimize.root
   :impl: scipy.optimize.minpack._root_hybr
   :method: hybr
