.. automodule:: scipy.ndimage
   :no-members:
   :no-inherited-members:
   :no-special-members:
