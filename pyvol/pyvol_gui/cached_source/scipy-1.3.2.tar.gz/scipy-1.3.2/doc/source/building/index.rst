.. _building:

Building from sources
=====================

.. note::

   If you are only trying to install SciPy, see
   :doc:`../install_upgrade`.

Build instructions for different operating systems:

.. toctree::
   :maxdepth: 2

   linux
   windows
   macosx

