:orphan:

{{ fullname }}
{{ underline }}

.. currentmodule:: {{ module }}

.. autoproperty:: {{ objname }}