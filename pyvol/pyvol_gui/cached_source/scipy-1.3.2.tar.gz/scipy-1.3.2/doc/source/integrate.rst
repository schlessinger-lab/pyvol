.. automodule:: scipy.integrate
   :no-members:
   :no-inherited-members:
   :no-special-members:
