
__version__ = "1.2.38"
__guiversion__ = "1.1.6"
