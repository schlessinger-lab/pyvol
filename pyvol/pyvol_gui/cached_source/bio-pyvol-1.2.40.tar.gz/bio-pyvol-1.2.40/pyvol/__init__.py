
__version__ = "1.2.40"
__guiversion__ = "1.1.8"
