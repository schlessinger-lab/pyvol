
__version__ = "1.2.42"
__guiversion__ = "1.1.10"
