

class MSMSError(Exception):
    """ Raised when MSMS fails to run correctly for any reason

    """
    pass
